import React, { useState, useEffect } from 'react';
import { View, Text, FlatList, Image, TouchableOpacity, StyleSheet, RefreshControl } from 'react-native';
import AsyncStorage from '@react-native-async-storage/async-storage';
import api from '../services/api';

export default function HomeScreen({ navigation }) {
    const [credits, setCredits] = useState(0);
    const [history, setHistory] = useState([]);
    const [refreshing, setRefreshing] = useState(false);

    useEffect(() => {
        loadData();
    }, []);

    const loadData = async () => {
        try {
            const [creditsData, historyData] = await Promise.all([
                api.getCredits(),
                api.getHistory()
            ]);
            setCredits(creditsData.credits);
            setHistory(historyData.images);
        } catch (error) {
            console.error(error);
        }
    };

    const onRefresh = async () => {
        setRefreshing(true);
        await loadData();
        setRefreshing(false);
    };

    const handleLogout = async () => {
        await AsyncStorage.removeItem('token');
        navigation.replace('Login');
    };

    return (
        <View style={styles.container}>
            {/* Header */}
            <View style={styles.header}>
                <View>
                    <Text style={styles.greeting}>My Studio</Text>
                    <Text style={styles.credits}>{credits} credits available</Text>
                </View>
                <TouchableOpacity onPress={handleLogout}>
                    <Text style={styles.logout}>Logout</Text>
                </TouchableOpacity>
            </View>

            {/* History Grid */}
            <FlatList
                data={history}
                keyExtractor={(item) => item.id}
                numColumns={2}
                refreshControl={<RefreshControl refreshing={refreshing} onRefresh={onRefresh} />}
                renderItem={({ item }) => (
                    <View style={styles.imageCard}>
                        <Image source={{ uri: item.imageUrl }} style={styles.image} />
                    </View>
                )}
                ListHeaderComponent={
                    <TouchableOpacity
                        style={styles.generateCard}
                        onPress={() => navigation.navigate('Generate')}
                    >
                        <Text style={styles.plusIcon}>+</Text>
                        <Text style={styles.generateText}>New Generation</Text>
                    </TouchableOpacity>
                }
                contentContainerStyle={styles.list}
            />
        </View>
    );
}

const styles = StyleSheet.create({
    container: {
        flex: 1,
        backgroundColor: '#f8f9fa',
    },
    header: {
        padding: 20,
        paddingTop: 60,
        backgroundColor: '#fff',
        flexDirection: 'row',
        justifyContent: 'space-between',
        alignItems: 'center',
        borderBottomWidth: 1,
        borderBottomColor: '#eee',
    },
    greeting: {
        fontSize: 24,
        fontWeight: 'bold',
    },
    credits: {
        color: '#666',
        marginTop: 5,
    },
    logout: {
        color: '#dc3545',
    },
    list: {
        padding: 10,
    },
    imageCard: {
        flex: 1,
        margin: 5,
        aspectRatio: 1,
        borderRadius: 10,
        overflow: 'hidden',
        backgroundColor: '#fff',
    },
    image: {
        width: '100%',
        height: '100%',
    },
    generateCard: {
        backgroundColor: '#000',
        margin: 5,
        padding: 20,
        borderRadius: 10,
        alignItems: 'center',
        justifyContent: 'center',
        marginBottom: 15,
    },
    plusIcon: {
        color: '#fff',
        fontSize: 30,
        fontWeight: 'bold',
    },
    generateText: {
        color: '#fff',
        marginTop: 5,
        fontWeight: '600',
    },
});
