import React, { useState, useEffect } from 'react';
import { View, Text, Image, TouchableOpacity, StyleSheet, ScrollView, Alert, ActivityIndicator } from 'react-native';
import * as ImagePicker from 'expo-image-picker';
import api from '../services/api';

export default function GenerateScreen({ navigation }) {
    const [productImage, setProductImage] = useState(null);
    const [models, setModels] = useState([]);
    const [selectedModel, setSelectedModel] = useState(null);
    const [loading, setLoading] = useState(false);
    const [generating, setGenerating] = useState(false);

    useEffect(() => {
        loadPresets();
    }, []);

    const loadPresets = async () => {
        try {
            console.log('Loading presets...');
            const data = await api.getPresets();
            console.log('Presets loaded:', data);
            console.log('Models count:', data.models?.length);
            console.log('Locations count:', data.locations?.length);
            setModels(data.models || []);
            Alert.alert('Debug', `Loaded ${data.models?.length || 0} models`);
        } catch (error) {
            console.error('Error loading presets:', error);
            Alert.alert('Error', `Failed to load presets: ${error.message}`);
        }
    };

    const pickImage = async () => {
        const result = await ImagePicker.launchImageLibraryAsync({
            mediaTypes: ImagePicker.MediaTypeOptions.Images,
            allowsEditing: true,
            quality: 1,
        });

        if (!result.canceled) {
            setProductImage(result.assets[0]);
        }
    };

    const handleGenerate = async () => {
        if (!productImage || !selectedModel) {
            Alert.alert('Error', 'Please select product and model');
            return;
        }

        setGenerating(true);

        try {
            await api.generateImage(productImage, {
                modelId: selectedModel,
                productType: 'clothing'
            });

            Alert.alert('Success', 'Image generated!');
            navigation.goBack();
        } catch (error) {
            Alert.alert('Error', error.message);
        } finally {
            setGenerating(false);
        }
    };

    return (
        <ScrollView style={styles.container}>
            <Text style={styles.sectionTitle}>1. Upload Product</Text>
            <TouchableOpacity style={styles.uploadBox} onPress={pickImage}>
                {productImage ? (
                    <Image source={{ uri: productImage.uri }} style={styles.preview} />
                ) : (
                    <Text style={styles.uploadText}>Tap to upload photo</Text>
                )}
            </TouchableOpacity>

            <Text style={styles.sectionTitle}>2. Choose Model</Text>
            <ScrollView horizontal showsHorizontalScrollIndicator={false} style={styles.modelList}>
                {models.map((model) => (
                    <TouchableOpacity
                        key={model.id}
                        style={[styles.modelCard, selectedModel === model.id && styles.selectedModel]}
                        onPress={() => setSelectedModel(model.id)}
                    >
                        <Image source={{ uri: model.image }} style={styles.modelImage} />
                        <Text style={styles.modelName} numberOfLines={1}>{model.name}</Text>
                    </TouchableOpacity>
                ))}
            </ScrollView>

            <TouchableOpacity
                style={[styles.generateBtn, (!productImage || !selectedModel) && styles.disabledBtn]}
                onPress={handleGenerate}
                disabled={generating || !productImage || !selectedModel}
            >
                {generating ? (
                    <ActivityIndicator color="#fff" />
                ) : (
                    <Text style={styles.generateBtnText}>Generate Image</Text>
                )}
            </TouchableOpacity>
        </ScrollView>
    );
}

const styles = StyleSheet.create({
    container: {
        flex: 1,
        backgroundColor: '#fff',
        padding: 20,
    },
    sectionTitle: {
        fontSize: 18,
        fontWeight: 'bold',
        marginTop: 20,
        marginBottom: 10,
        color: '#000000',
    },
    uploadBox: {
        height: 200,
        borderWidth: 2,
        borderColor: '#eeeeee',
        borderStyle: 'dashed',
        borderRadius: 10,
        justifyContent: 'center',
        alignItems: 'center',
        backgroundColor: '#f9f9f9',
    },
    uploadText: {
        color: '#666666',
        fontSize: 16,
    },
    preview: {
        width: '100%',
        height: '100%',
        borderRadius: 10,
    },
    modelList: {
        flexDirection: 'row',
        marginBottom: 20,
    },
    modelCard: {
        width: 100,
        marginRight: 10,
        borderRadius: 8,
        borderWidth: 2,
        borderColor: 'transparent',
    },
    selectedModel: {
        borderColor: '#000000',
    },
    modelImage: {
        width: '100%',
        height: 100,
        borderRadius: 6,
    },
    modelName: {
        textAlign: 'center',
        fontSize: 12,
        marginTop: 5,
        color: '#000000',
    },
    generateBtn: {
        backgroundColor: '#000',
        padding: 18,
        borderRadius: 12,
        alignItems: 'center',
        marginTop: 30,
        marginBottom: 50,
    },
    disabledBtn: {
        backgroundColor: '#ccc',
    },
    generateBtnText: {
        color: '#fff',
        fontSize: 18,
        fontWeight: 'bold',
    },
});
