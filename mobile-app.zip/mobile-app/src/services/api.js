import { API_URL } from '../config';

class APIService {
    constructor() {
        this.token = null;
    }

    setToken(token) {
        this.token = token;
    }

    async request(endpoint, options = {}) {
        const headers = {
            'Content-Type': 'application/json',
            ...options.headers,
        };

        if (this.token) {
            headers['Authorization'] = `Bearer ${this.token}`;
        }

        try {
            const response = await fetch(`${API_URL}${endpoint}`, {
                ...options,
                headers,
            });

            const data = await response.json();

            if (!data.success) {
                throw new Error(data.error || 'Request failed');
            }

            return data;
        } catch (error) {
            console.error('API Request Error:', error);
            throw error;
        }
    }

    // Auth
    async register(email, password) {
        const data = await this.request('/api/auth/register', {
            method: 'POST',
            body: JSON.stringify({ email, password }),
        });
        return data;
    }

    async login(email, password) {
        const data = await this.request('/api/auth/login', {
            method: 'POST',
            body: JSON.stringify({ email, password }),
        });
        return data;
    }

    async getMe() {
        return this.request('/api/auth/me');
    }

    // Content
    async getPresets() {
        return this.request('/api/presets');
    }

    async getCredits() {
        return this.request('/api/credits');
    }

    async getHistory() {
        return this.request('/api/history');
    }

    async generateImage(productImage, options = {}) {
        const formData = new FormData();

        // Append product image
        formData.append('productImage', {
            uri: productImage.uri,
            type: 'image/jpeg',
            name: 'product.jpg',
        });

        // Append options
        if (options.modelId) formData.append('modelId', options.modelId);
        if (options.locationId) formData.append('locationId', options.locationId);
        if (options.productType) formData.append('productType', options.productType);
        if (options.action) formData.append('action', options.action);

        // Custom fetch for FormData (headers are handled differently)
        const headers = {
            'Authorization': `Bearer ${this.token}`,
            // Content-Type is set automatically for FormData
        };

        const response = await fetch(`${API_URL}/api/generate`, {
            method: 'POST',
            headers,
            body: formData,
        });

        const data = await response.json();

        if (!data.success) {
            throw new Error(data.error || 'Generation failed');
        }

        return data;
    }
}

export default new APIService();
