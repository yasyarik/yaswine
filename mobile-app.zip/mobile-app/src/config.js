// API Configuration
export const API_URL = 'https://api.myugc.studio';
