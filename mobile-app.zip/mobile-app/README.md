# My UGC Studio - Mobile App

Это мобильное приложение для iOS и Android, созданное на React Native (Expo).

## 🚀 Как запустить

### 1. Установите Node.js
Убедитесь, что у вас установлен Node.js (версия 16+).

### 2. Установите зависимости
Откройте терминал в этой папке и выполните:
```bash
npm install
```

### 3. Запустите приложение
```bash
npx expo start
```

Это откроет QR-код. 
- Скачайте приложение **Expo Go** на телефон (App Store / Google Play).
- Отсканируйте QR-код камерой телефона.

---

## 📱 Сборка для App Store / Google Play

Чтобы создать настоящий файл приложения (.ipa / .apk):

1. Установите EAS CLI:
```bash
npm install -g eas-cli
```

2. Войдите в аккаунт Expo:
```bash
eas login
```

3. Настройте проект:
```bash
eas build:configure
```

4. Запустите сборку:
```bash
eas build --platform ios
# или
eas build --platform android
```

---

## ⚙️ Конфигурация

Адрес API сервера находится в файле `src/config.js`:
```javascript
export const API_URL = 'https://api.myugc.studio';
```
